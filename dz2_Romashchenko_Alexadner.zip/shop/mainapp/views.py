from django.shortcuts import render

# Create your views here.

def main(request):
    context = {'username': 'my friend', 'array': [1, 2, 3, 4, 5]}
    return render(request, 'mainapp/main.html', context)

def products(request):
    links_menu = [
        {'href': 'products_all', 'name': 'все'},
        {'href': 'products_home', 'name': 'дом'},
        {'href': 'products_office', 'name': 'офис'},
        {'href': 'products_modern', 'name': 'модерн'},
        {'href': 'products_classic', 'name': 'классика'},
]
    return render(request, 'mainapp/products.html', links_menu)

def contacts(request):
    return render(request, 'mainapp/contacts.html')

def products2(request):
    return render(request, 'mainapp/products2.html')